package com.betulgules.capstoneproject.ui.search

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.betulgules.capstoneproject.MainApplication
import com.betulgules.capstoneproject.R
import com.betulgules.capstoneproject.common.viewBinding
import com.betulgules.capstoneproject.data.model.response.SearchProductResponse
import com.betulgules.capstoneproject.databinding.FragmentSearchBinding
import com.betulgules.capstoneproject.ui.cart.CartAdapter
import com.betulgules.capstoneproject.ui.home.HomeFragmentDirections
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchFragment : Fragment(R.layout.fragment_search) {

    private val binding by viewBinding(FragmentSearchBinding::bind)

    private val searchAdapter = SearchAdapter(onProductClick = ::onProductClick)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        searchProduct()
    }
    private fun searchProduct() {
        MainApplication.productService?.searchProduct()?.enqueue(object :
            Callback<SearchProductResponse> {

            override fun onResponse(call: Call<SearchProductResponse>, response: Response<SearchProductResponse>) {
                val result = response.body()

                if (result?.status == 200) {
                    searchAdapter.submitList(result.products.orEmpty())
                }
                else {
                    Toast.makeText(requireContext(), result?.message, Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<SearchProductResponse>, t: Throwable) {
                Log.e("SearchProduct", t.message.orEmpty())
            }
        })
    }

    private fun onProductClick(id: Int) {
        findNavController().navigate(SearchFragmentDirections.actionSearchFragmentToDetailFragment(id))
    }
}
