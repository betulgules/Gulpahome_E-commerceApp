package com.betulgules.capstoneproject.data.model.response

data class GetCategoriesResponse(
    val categories: String?,
    val status: Int?,
    val message: String?
)
