package com.betulgules.capstoneproject.data.model.request

data class GetCartProductsRequest(
    val userId: String?
)
