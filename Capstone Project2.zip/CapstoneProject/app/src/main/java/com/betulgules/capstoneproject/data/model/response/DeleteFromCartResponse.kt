package com.betulgules.capstoneproject.data.model.response

data class DeleteFromCartResponse(
    val status: Int?,
    val message: String?
)
