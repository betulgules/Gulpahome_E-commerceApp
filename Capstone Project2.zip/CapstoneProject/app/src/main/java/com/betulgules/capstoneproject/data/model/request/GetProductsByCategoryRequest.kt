package com.betulgules.capstoneproject.data.model.request

data class GetProductsByCategoryRequest(
    val category: String?
)
