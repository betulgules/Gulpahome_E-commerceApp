package com.betulgules.capstoneproject.data.model.response

data class AddToCartResponse(
    val status: Int?,
    val message: String?
)
