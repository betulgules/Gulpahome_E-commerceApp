package com.betulgules.capstoneproject.data.model.response

data class ClearCartResponse(
    val status: Int?,
    val message: String?
)