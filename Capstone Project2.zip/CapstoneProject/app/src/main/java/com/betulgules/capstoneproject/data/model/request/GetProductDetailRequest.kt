package com.betulgules.capstoneproject.data.model.request

data class GetProductDetailRequest(
    val id: Int?
)
