package com.betulgules.capstoneproject.data.model.request

data class DeleteFromCartRequest(
    val id: Int?
)
